import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestApp {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://myrealtordash.clareityiam.net/idp/login");
		driver.findElement(By.name("username")).sendKeys("1234567");
		driver.findElement(By.name("password")).sendKeys("abcdefg");
		driver.findElement(By.id("loginbtn")).click();
		//*[@id="form_login"]/div[1]/input
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if(driver.findElement(By.className("error")).isDisplayed())
			System.out.println("Login with Incorrect Credentials: Passed");
		else
			System.out.println("Login with Incorrect Credentials: Failed");
		//driver.close();
	}
}
