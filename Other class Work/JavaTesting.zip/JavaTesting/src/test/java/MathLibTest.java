import static org.junit.Assert.*;

import org.junit.Test;

public class MathLibTest {

	@Test
	public void test_isEven() {
		MathLib obj = new MathLib();
		assert(obj.ifEven(4) == true);
		assert(obj.ifEven(5) == false);
		
	}

	@Test
	public void test_add_int_non_zero() {
		MathLib obj = new MathLib();
		assert(obj.add(4, 7) == 11);
	}

	@Test
	public void test_add_int_zero() {
		MathLib obj = new MathLib();
		assert(obj.add(4, 0) == 4);
	}
	
	@Test
	public void test_add_int_negative() {
		MathLib obj = new MathLib();
		assert(obj.add(-8, -7) == -15);
	}
	
	@Test
	public void test_add_double() {
		MathLib obj = new MathLib();
		assert(obj.add(3.0, -4.0) == -1.0);		
	}
	
	@Test
	public void test_remainder() {
		MathLib obj = new MathLib();
		assert(obj.remainder(10,2) == 0);
		assert(obj.remainder(15,4) == 3);
	}

}
